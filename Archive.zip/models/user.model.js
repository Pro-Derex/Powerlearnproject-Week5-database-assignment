const db = require("../config/db.config");

const User = {
    create: (username, hashedPassword, result) => {
        db.query("INSERT INTO Users (username, password) VALUES (?, ?)", [username, hashedPassword], (err, res) => {
            if (err) {
                result(err, null);
                return;
            }
            result(null, { id: res.insertId, username });
        });
    },

    findByUsername: (username, result) => {
        db.query("SELECT * FROM Users WHERE username = ?", [username], (err, res) => {
            if (err) {
                result(err, null);
                return;
            }
            result(null, res[0]);
        });
    }
};

module.exports = User;
