const db = require("../config/db.config");

const Expense = {
    create: (userId, amount, date, category, result) => {
        db.query("INSERT INTO Expenses (user_id, amount, date, category) VALUES (?, ?, ?, ?)", [userId, amount, date, category], (err, res) => {
            if (err) {
                result(err, null);
                return;
            }
            result(null, { id: res.insertId });
        });
    },

    findByUserId: (userId, result) => {
        db.query("SELECT * FROM Expenses WHERE user_id = ?", [userId], (err, res) => {
            if (err) {
                result(err, null);
                return;
            }
            result(null, res);
        });
    }
};

module.exports = Expense;
