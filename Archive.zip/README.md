## Setup

1. Clone the repository: `https://github.com/Powerlearnproject/week-5-Pro-Derex-2.git`
2. Install dependencies: `npm install`
3. Set up the database and configure environment variables in `.env` file.
4. Run the application: `npm start`
