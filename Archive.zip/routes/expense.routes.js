const express = require("express");
const router = express.Router();
const expenseController = require("../controllers/expense.controller");
const authMiddleware = require("../middleware/auth.middleware");

router.post("/", authMiddleware, expenseController.addExpense);
router.get("/", authMiddleware, expenseController.viewExpenses);

module.exports = router;
