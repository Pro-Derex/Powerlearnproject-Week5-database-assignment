const Login = require('./LoginController');
const Register = require('./RegisterController');
const Expense = require('./ExpenseController');

module.exports = {Register, Login, Expense};