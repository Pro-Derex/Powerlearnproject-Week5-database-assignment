const Expense = require("../models/expense.model");

exports.addExpense = (req, res) => {
    const { amount, date, category } = req.body;
    const userId = req.userId;  // From authenticated user

    Expense.create(userId, amount, date, category, (err, expense) => {
        if (err) return res.status(500).send("Error adding expense");

        res.status(201).send({ message: "Expense added successfully" });
    });
};

exports.viewExpenses = (req, res) => {
    const userId = req.userId;

    Expense.findByUserId(userId, (err, expenses) => {
        if (err) return res.status(500).send("Error fetching expenses");

        res.status(200).send(expenses);
    });
};
