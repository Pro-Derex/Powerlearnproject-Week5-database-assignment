const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user.model");

exports.register = (req, res) => {
    const { username, password } = req.body;

    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) return res.status(500).send("Error hashing password");

        User.create(username, hashedPassword, (err, user) => {
            if (err) return res.status(500).send("Error creating user");

            res.status(201).send({ message: "User registered successfully" });
        });
    });
};

exports.login = (req, res) => {
    const { username, password } = req.body;

    User.findByUsername(username, (err, user) => {
        if (err || !user) return res.status(400).send("User not found");

        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (!isMatch) return res.status(400).send("Invalid credentials");

            const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: "1h" });
            res.status(200).send({ token });
        });
    });
};
